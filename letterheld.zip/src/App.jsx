import React, { useEffect, useMemo, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Volume2, Home, RotateCcw, Check, X, Sparkles, Lock, Printer } from "lucide-react";

const CHILD_NAME = "Kobe";
const LETTERS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".split("");
const COLORS = ["pink", "yellow", "green", "blue", "purple"];
const TREASURES = ["💎", "🪙", "👑", "⭐"];
const PRAISES = [`Goed gedaan, ${CHILD_NAME}!`, `Super, ${CHILD_NAME}!`, "Knap gewerkt!", "Jij bent een echte letterheld!", "Fantastisch!"];
const AVATARS = [
  { emoji: "🦁", name: "Leeuw" }, { emoji: "🦕", name: "Dino" },
  { emoji: "🐵", name: "Aap" }, { emoji: "🚒", name: "Brandweerheld" },
  { emoji: "🚀", name: "Ruimteheld" }
];
const WORDS = [
  ["A","AAP","🐵","de"], ["B","BEER","🐻","de"], ["C","CITROEN","🍋","de"],
  ["D","DINO","🦕","de"], ["E","EEND","🦆","de"], ["F","FIETS","🚲","de"],
  ["G","GEIT","🐐","de"], ["H","HOND","🐶","de"], ["I","IJS","🍦","het"],
  ["J","JAS","🧥","de"], ["K","KAT","🐱","de"], ["L","LEEUW","🦁","de"],
  ["M","MUIS","🐭","de"], ["N","NOOT","🌰","de"], ["O","OLIFANT","🐘","de"],
  ["P","PAARD","🐴","het"], ["Q","QUICHE","🥧","de"], ["R","ROOS","🌹","de"],
  ["S","SLANG","🐍","de"], ["T","TREIN","🚂","de"], ["U","UIL","🦉","de"],
  ["V","VIS","🐟","de"], ["W","WOLK","☁️","de"], ["X","XYLOFOON","🎵","de"],
  ["Y","YOGHURT","🥣","de"], ["Z","ZEBRA","🦓","de"]
].map(([letter,word,emoji,article])=>({letter,word,emoji,article}));

const shuffle = a => [...a].sort(() => Math.random() - .5);
const options = (correct, pool, count=4) => shuffle([correct, ...shuffle(pool.filter(x => x !== correct)).slice(0,count-1)]);
function speak(text, slow=false){
  if (!("speechSynthesis" in window)) return;
  speechSynthesis.cancel();
  const u = new SpeechSynthesisUtterance(text);
  u.lang="nl-BE"; u.rate=slow?.68:.86; speechSynthesis.speak(u);
}
function sayLetterAndWord(letter, word){ speak(`${letter}. ${word}.`, true); }
function Btn({children,onClick,className="",disabled=false}){return <button disabled={disabled} onClick={onClick} className={`btn ${className}`}>{children}</button>}

export default function App(){
  const [screen,setScreen]=useState("home");
  const [treasures,setTreasures]=useState(()=>Number(localStorage.getItem("kobe-treasures")||0));
  const [completed,setCompleted]=useState(()=>JSON.parse(localStorage.getItem("kobe-completed")||"[]"));
  const [avatar,setAvatar]=useState(()=>JSON.parse(localStorage.getItem("kobe-avatar")||"null"));
  const [feedback,setFeedback]=useState(null), [round,setRound]=useState(0), [selected,setSelected]=useState("K"), [streak,setStreak]=useState(0);
  useEffect(()=>localStorage.setItem("kobe-treasures",treasures),[treasures]);
  useEffect(()=>localStorage.setItem("kobe-completed",JSON.stringify(completed)),[completed]);
  useEffect(()=>{if(avatar)localStorage.setItem("kobe-avatar",JSON.stringify(avatar))},[avatar]);
  const reward=a=>{setTreasures(v=>v+1);setStreak(v=>v+1);if(!completed.includes(a))setCompleted(v=>[...v,a]);setFeedback("good");speak(PRAISES[Math.floor(Math.random()*PRAISES.length)])};
  const miss=()=>{setStreak(0);setFeedback("try");speak(`Bijna, ${CHILD_NAME}. Probeer nog eens.`)};
  const next=()=>{setRound(v=>v+1);setFeedback(null)};
  const home=()=>{setScreen("home");setFeedback(null)};
  if(!avatar)return <AvatarPicker onPick={setAvatar}/>;
  return <div className="app"><header><button className="brand" onClick={home}><span>{avatar.emoji}</span>Kobe's Letterheld</button><div className="status">{screen!=="home"&&<Btn onClick={home} className="ghost"><Home size={20}/>Start</Btn>}<b>🧰 {treasures}</b>{streak>=2&&<b>🔥 {streak}</b>}</div></header>
    <main><AnimatePresence mode="wait">
      {screen==="home"&&<HomeScreen avatar={avatar} setScreen={setScreen} treasures={treasures}/>} 
      {screen==="alphabet"&&<Alphabet selected={selected} setSelected={setSelected}/>} 
      {screen==="games"&&<GameMenu setScreen={setScreen}/>} 
      {screen==="find"&&<FindLetter key={`f${round}`} round={round} reward={()=>reward("find")} miss={miss} next={next} feedback={feedback}/>} 
      {screen==="sound"&&<SoundQuiz key={`s${round}`} round={round} reward={()=>reward("sound")} miss={miss} next={next} feedback={feedback}/>} 
      {screen==="animal"&&<FindAnimal key={`a${round}`} round={round} reward={()=>reward("animal")} miss={miss} next={next} feedback={feedback}/>} 
      {screen==="train"&&<LetterTrain key={`t${round}`} round={round} reward={()=>reward("train")} miss={miss} next={next} feedback={feedback}/>} 
      {screen==="word"&&<WordBuilder key={`w${round}`} round={round} reward={()=>reward("word")} miss={miss} next={next} feedback={feedback}/>} 
      {screen==="memory"&&<Memory reward={()=>reward("memory")}/>} 
      {screen==="treasure"&&<TreasureRoom treasures={treasures} reset={()=>{setTreasures(0);setCompleted([]);setStreak(0)}} changeAvatar={()=>{localStorage.removeItem("kobe-avatar");setAvatar(null)}}/>}
    </AnimatePresence></main><AnimatePresence>{feedback==="good"&&<Celebration/>}</AnimatePresence></div>
}

function AvatarPicker({onPick}){return <div className="center-page"><div><div className="hero-emoji">👋</div><h1>Dag Kobe!</h1><p>Kies jouw lettervriend.</p><div className="avatar-grid">{AVATARS.map(a=><motion.button whileTap={{scale:.92}} key={a.name} onClick={()=>{onPick(a);speak(`Hallo Kobe! Ik ben jouw ${a.name}.`)}} className="avatar"><span>{a.emoji}</span><b>{a.name}</b></motion.button>)}</div></div></div>}
function Page({children}){return <motion.div initial={{opacity:0,y:14}} animate={{opacity:1,y:0}} exit={{opacity:0,y:-10}}>{children}</motion.div>}
function Title({emoji,title,subtitle}){return <div className="title"><div>{emoji}</div><h1>{title}</h1><p>{subtitle}</p></div>}
function HomeScreen({avatar,setScreen,treasures}){const cards=[["alphabet","🔤","Letters ontdekken","Kijken en luisteren","blue"],["games","🎮","Spelletjes spelen","Zoeken, luisteren en puzzelen","green"],["treasure","🧰","Mijn schatkist",`Al ${treasures} schatten gevonden`,"orange"]];return <Page><section className="hero"><div><span className="tag"><Sparkles size={16}/>Voor Kobe</span><h1>Kobe, word jij een <em>Letterheld?</em></h1><p>Kies één groot avontuur.</p></div><motion.div animate={{y:[0,-8,0]}} transition={{repeat:Infinity,duration:2.5}} className="hero-friend">{avatar.emoji}</motion.div></section><div className="home-grid">{cards.map(c=><motion.button whileHover={{y:-5}} whileTap={{scale:.97}} key={c[0]} onClick={()=>setScreen(c[0])} className={`home-card ${c[4]}`}><span>{c[1]}</span><h2>{c[2]}</h2><p>{c[3]}</p></motion.button>)}</div></Page>}
function GameMenu({setScreen}){const games=[["find","🔎","Vind de letter"],["sound","👂","Luister goed"],["animal","🐾","Zoek het dier"],["train","🚂","Lettertrein"],["word","🧩","Bouw een woord"],["memory","🧠","Lettermemory"]];return <Page><Title emoji="🎮" title="Kies een spel" subtitle="Tik op wat je wil spelen."/><div className="game-grid">{games.map((g,i)=><motion.button whileTap={{scale:.94}} key={g[0]} onClick={()=>setScreen(g[0])} className={`game-tile ${COLORS[i%COLORS.length]}`}><span>{g[1]}</span><b>{g[2]}</b></motion.button>)}</div></Page>}
function Alphabet({selected,setSelected}){const ex=WORDS.find(w=>w.letter===selected);return <Page><Title emoji="🔤" title="Ontdek letters" subtitle="Tik op een letter. Luister goed."/><div className="alphabet-layout"><section className="letter-card"><motion.div key={selected} initial={{scale:.5}} animate={{scale:1}} className="big-letter">{selected}</motion.div><div className="example">{ex.emoji}</div><h2>{ex.word.toLowerCase()}</h2><Btn onClick={()=>sayLetterAndWord(selected,ex.word)} className="primary"><Volume2/>Luister</Btn></section><div className="letters">{LETTERS.map((l,i)=><motion.button whileTap={{scale:.9}} key={l} onClick={()=>{setSelected(l);const w=WORDS.find(x=>x.letter===l);sayLetterAndWord(l,w.word)}} className={`${COLORS[i%COLORS.length]} ${selected===l?"chosen":""}`}>{l}</motion.button>)}</div></div></Page>}
function FindLetter(p){const target=LETTERS[p.round%26], opts=useMemo(()=>options(target,LETTERS),[target]);useEffect(()=>{const t=setTimeout(()=>speak(`Zoek de letter ${target}.`,true),250);return()=>clearTimeout(t)},[target]);return <GameShell title="Vind de letter" emoji="🔎" instruction={`Waar staat de ${target}?`} listen={()=>speak(`Zoek de letter ${target}.`,true)} {...p}>{opts.map((o,i)=><Answer key={o} color={i} disabled={!!p.feedback} onClick={()=>o===target?p.reward():p.miss()}>{o}</Answer>)}</GameShell>}
function SoundQuiz(p){const target=LETTERS[(p.round*3+4)%26],opts=useMemo(()=>options(target,LETTERS),[target]);useEffect(()=>{const t=setTimeout(()=>speak(target,true),250);return()=>clearTimeout(t)},[target]);return <GameShell title="Luister goed" emoji="👂" instruction="Welke letter hoor je?" listen={()=>speak(target,true)} {...p}>{opts.map((o,i)=><Answer key={o} color={i} disabled={!!p.feedback} onClick={()=>o===target?p.reward():p.miss()}>{o}</Answer>)}</GameShell>}
function FindAnimal(p){const animals=WORDS.filter(w=>["🐵","🐻","🦕","🦆","🐐","🐶","🐱","🦁","🐭","🐘","🐴","🐍","🦉","🐟","🦓"].includes(w.emoji)),target=animals[p.round%animals.length],opts=useMemo(()=>options(target,animals),[target]);useEffect(()=>{const t=setTimeout(()=>speak(`Tik op ${target.article} ${target.word.toLowerCase()}.`),250);return()=>clearTimeout(t)},[target]);return <GameShell title="Zoek het dier" emoji="🐾" instruction={`Tik op ${target.article} ${target.word.toLowerCase()}.`} listen={()=>speak(`Tik op ${target.article} ${target.word.toLowerCase()}.`)} {...p}>{opts.map((o,i)=><Answer key={o.word} color={i} disabled={!!p.feedback} onClick={()=>o.word===target.word?p.reward():p.miss()}>{o.emoji}</Answer>)}</GameShell>}
function LetterTrain(p){const start=(p.round*3)%22,target=LETTERS[start+3],shown=LETTERS.slice(start,start+3),opts=useMemo(()=>options(target,LETTERS),[target]);return <GameShell title="Lettertrein" emoji="🚂" instruction="Welke letter komt nu?" listen={()=>speak(`De trein zegt: ${shown.join(", ")}. Welke letter komt nu?`,true)} {...p}><div className="train">🚂 {shown.map(l=><span key={l}>{l}</span>)} <span>?</span></div>{opts.map((o,i)=><Answer key={o} color={i} disabled={!!p.feedback} onClick={()=>o===target?p.reward():p.miss()}>{o}</Answer>)}</GameShell>}
function WordBuilder(p){const small=WORDS.filter(w=>w.word.length<=4),item=small[p.round%small.length],[picked,setPicked]=useState([]),letters=useMemo(()=>shuffle(item.word.split("").map((l,i)=>({l,id:i}))),[item]);const add=x=>{if(picked.some(v=>v.id===x.id)||p.feedback)return;const n=[...picked,x];setPicked(n);if(n.length===item.word.length)n.map(v=>v.l).join("")===item.word?p.reward():p.miss()};return <Page><Title emoji="🧩" title="Bouw een woord" subtitle="Tik op de letters in de juiste volgorde."/><section className="panel"><div className="word-emoji">{item.emoji}</div><Btn onClick={()=>speak(item.word)} className="round"><Volume2/></Btn><div className="slots">{item.word.split("").map((_,i)=><div key={i}>{picked[i]?.l}</div>)}</div><div className="word-letters">{letters.map((x,i)=><button key={x.id} disabled={picked.some(v=>v.id===x.id)||!!p.feedback} onClick={()=>add(x)} className={COLORS[i%COLORS.length]}>{x.l}</button>)}</div>{!p.feedback&&picked.length>0&&<Btn onClick={()=>setPicked([])} className="ghost"><RotateCcw size={18}/>Opnieuw</Btn>}<Feedback value={p.feedback} next={p.next}/></section></Page>}
function Memory({reward}){const base=["A","B","K","M","S","V"],[cards,setCards]=useState(()=>shuffle([...base,...base].map((l,i)=>({l,id:i})))),[open,setOpen]=useState([]),[done,setDone]=useState([]),[won,setWon]=useState(false);const flip=c=>{if(open.length===2||open.some(x=>x.id===c.id)||done.includes(c.id))return;const n=[...open,c];setOpen(n);if(n.length===2){if(n[0].l===n[1].l)setTimeout(()=>{setDone(d=>[...d,n[0].id,n[1].id]);setOpen([]);if(done.length+2===cards.length){setWon(true);reward()}},450);else setTimeout(()=>setOpen([]),800)}};const reset=()=>{setCards(shuffle([...base,...base].map((l,i)=>({l,id:i}))));setOpen([]);setDone([]);setWon(false)};return <Page><Title emoji="🧠" title="Lettermemory" subtitle="Zoek twee dezelfde letters."/><div className="memory">{cards.map(c=>{const seen=open.some(x=>x.id===c.id)||done.includes(c.id);return <button onClick={()=>flip(c)} key={c.id} className={seen?"seen":""}>{seen?c.l:"★"}</button>})}</div>{won&&<div className="win"><h2>Fantastisch, Kobe!</h2><Btn onClick={reset} className="primary">Nog een keer</Btn></div>}</Page>}
function TreasureRoom({treasures,reset,changeAvatar}){const diploma=treasures>=25;return <Page><Title emoji="🧰" title="Kobe's schatkist" subtitle="Elke schat heb jij zelf verdiend."/><div className="treasures">{Array.from({length:Math.min(treasures,40)},(_,i)=><motion.div initial={{scale:0}} animate={{scale:1}} key={i}>{TREASURES[i%4]}</motion.div>)}</div><section className="panel diploma">{diploma?<><div>🏆</div><h2>Diploma Letterheld</h2><p>Proficiat Kobe! Je kent al heel veel letters.</p><Btn onClick={()=>window.print()} className="primary"><Printer/>Print diploma</Btn></>:<><Lock/><h2>Diploma bij 25 schatten</h2><p>Nog {25-treasures} te gaan. Jij kan dit!</p></>}</section><div className="actions"><Btn onClick={changeAvatar}>Andere lettervriend</Btn><Btn onClick={reset} className="ghost"><RotateCcw size={18}/>Schatkist leegmaken</Btn></div></Page>}
function Answer({children,onClick,disabled,color}){return <motion.button whileTap={{scale:.92}} disabled={disabled} onClick={onClick} className={`answer ${COLORS[color%5]}`}>{children}</motion.button>}
function GameShell({title,emoji,instruction,listen,feedback,next,children}){return <Page><Title emoji={emoji} title={title} subtitle="Vind het juiste antwoord en krijg een schat."/><section className="panel"><div className="instruction"><h2>{instruction}</h2><Btn onClick={listen} className="round primary"><Volume2/></Btn></div><div className="answers">{children}</div><Feedback value={feedback} next={next}/></section></Page>}
function Feedback({value,next}){return value?<div className={`feedback ${value}`}><h2>{value==="good"?<><Check/>Super, Kobe! +1 schat</>:<><X/>Bijna! Probeer opnieuw.</>}</h2><Btn onClick={next} className="primary">{value==="good"?"Volgende":"Nieuwe oefening"}</Btn></div>:null}
function Celebration(){return <div className="confetti">{["💎","✨","🪙","🎉","👑","⭐"].map((c,i)=><motion.div key={i} initial={{y:-50,x:`${12+i*15}vw`}} animate={{y:"105vh",rotate:360,opacity:[1,1,0]}} transition={{duration:1.8,delay:i*.06}}>{c}</motion.div>)}</div>}
