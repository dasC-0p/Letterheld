# Kobe's Letterheld

Speelse React-webapp om letters te ontdekken en herkennen.

## Lokaal starten

```bash
npm install
npm run dev
```

## Productieversie maken

```bash
npm run build
```

## Publiceren via GitHub Pages

1. Maak op GitHub een openbare repository met de naam `letterheld`.
2. Upload alle bestanden uit deze map naar de repository.
3. Open lokaal een terminal in deze map en voer uit:

```bash
npm install
npm run deploy
```

4. Ga in GitHub naar **Settings > Pages** en kies de branch `gh-pages` met map `/ (root)`.

De Vite-configuratie gebruikt een relatieve basis, zodat de app ook onder een repositorypad werkt.
